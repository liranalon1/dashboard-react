# deshboard-react

```bash
# install dependencies
npm install

#
npm run dev
```
